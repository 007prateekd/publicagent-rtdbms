from django.db import models
from django.contrib.auth.models import User

class Profile(models.Model):
    user = models.OneToOneField(User, on_delete=models.CASCADE)
    auth_token = models.CharField(max_length=100 )
    is_verified = models.BooleanField(default=False)
    created_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return self.user.username

class Element(models.Model):
	facility_id = models.CharField(max_length = 10)
	facility_name = models.CharField(max_length = 100)
	address = models.TextField()
	city =  models.CharField(max_length = 20)
	state = models.CharField(max_length = 5)
	zip_code = models.IntegerField()
	county_name = models.CharField(max_length = 20)
	phone_number = models.CharField(max_length = 20)
	measure_id = models.CharField(max_length = 10)
	measure_name = models.CharField(max_length = 100)
	score = models.FloatField(null = True, blank = True)
	sample = models.IntegerField(null = True, blank = True)
	location = models.CharField(max_length = 40, null = True, blank = True)