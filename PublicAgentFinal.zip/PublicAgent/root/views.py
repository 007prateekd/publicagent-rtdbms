from django.shortcuts import render
from django.core.mail import send_mail
from django.contrib.auth.models import User
from django.conf import settings
from django.shortcuts import render, redirect

def index(request):
	return render(request, "index.html")

def about(request):
	return render(request, "about.html")

def query(request):
	if request.method == "POST":
		name = request.POST["newsletter_input_name"]
		data = request.POST["newsletter_input_email"]
		username = request.user.username
		subject = f'Query From {username}'
		message = f'{name} Says: \n{data}'
		email_from = settings.EMAIL_HOST_USER
		recipient_list = [settings.EMAIL_HOST_USER]
		send_mail(subject, message, email_from, recipient_list)
		msg = "Your Query Has Been Sent Successfully"
		return render(request, "index.html", {"msgs1": msg})
	else:
		return redirect("/")