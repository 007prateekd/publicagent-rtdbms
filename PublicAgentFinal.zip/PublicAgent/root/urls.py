from django.urls import include, path
from . import views
from django.contrib import admin

urlpatterns = [
    path('', views.index, name = 'index'),
    path('about', views.about, name = 'about'),
    path('query', views.query, name='query')
]