from django.contrib import admin
from .models import *

admin.site.register(Profile)
admin.site.register(Element)

admin.site.site_title = 'PublicAgent'
admin.site.site_header = 'PublicAgent Administration'
admin.site.index_title = 'Site Admin'