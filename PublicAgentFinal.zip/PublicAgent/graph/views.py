from django.shortcuts import render, redirect
from django.contrib import messages
import matplotlib.pyplot as plt
import random
import time

def graph(request):
	random.seed(time.time())
	times = []
	for i in range(1000):
	  times.append(random.random())
  
	badge, rein, num = 5, 0, 0
	number = []
	for i in range(1000):
	  if rein + times[i] > badge:
	     number.append(num / 10)
	     rein, num = 0, 0
	  rein = rein + times[i]
	  num = num + 1

	time.sleep(5)
	plt.plot(number)
	plt.xlabel("Number Of Epochs")
	plt.ylabel("Perfomance Ratio (Time-Divided Batch / Fixed Batch)")
	plt.savefig("static/graph.png")
	plt.clf()
	
	return render(request, "graph.html")
	