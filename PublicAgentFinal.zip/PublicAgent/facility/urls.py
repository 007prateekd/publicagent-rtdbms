from django.urls import path
from . import views

urlpatterns = [
	path("best-facility", views.best_facility, name = "bf"),
] 