from django.shortcuts import render, redirect
from django.contrib import messages
from root.models import Element

def best_facility(request):
	if request.method == "POST":
		state = request.POST["state"]
		treatment = request.POST["treatment"]
		
		if state == "" and treatment == "":
			msg = "At Least One Of The Following Fields Must Be Filled:<br> \
			• State (For All Facilities In That State)<br>• Treatment(For All States That Provide It)"
			return render(request, "index.html", {"msgs": msg})
		if state == "":
			if Element.objects.filter(measure_id = treatment).exists():
				e = list(Element.objects.filter(measure_id = treatment).order_by("-score", "-sample").values())
			else:
				msg = "Invalid Treatment"
				return render(request, "index.html", {"msgs": msg})
		elif treatment == "":
			if Element.objects.filter(state = state).exists():
				e = list(Element.objects.filter(state = state).order_by("-score", "-sample").values())
			else:
				msg = "Invalid State"
				return render(request, "index.html", {"msgs": msg})
		else:
			if Element.objects.filter(state = state, measure_id = treatment).exists():
				e = list(Element.objects.filter(state = state, measure_id = treatment).order_by("-score", "-sample").values())
			else: 
				msg = "Invalid State Or Treatment"
				return render(request, "index.html", {"msgs": msg})

		return render(request, "best_facility.html", {"facilities": e})
	else:
		return redirect("/")
