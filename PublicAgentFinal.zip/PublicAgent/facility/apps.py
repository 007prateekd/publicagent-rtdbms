from django.apps import AppConfig


class FacilityConfig(AppConfig):
    name = 'facility'
