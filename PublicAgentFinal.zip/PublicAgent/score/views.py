from django.shortcuts import render, redirect
from django.contrib import messages
from root.models import Element
from django.contrib.auth.models import User, auth

def score(request):
	el = list(Element.objects.order_by().values_list("facility_id").distinct())
	el = sorted([x[0] for x in el])

	if request.method == "POST":
		f_id = request.POST["facility_id"]
		m_id = request.POST["measure"]
		score = float(request.POST["score"])

		msgs = ""
		f = 0
		if score < 0 or score > 100:
			f = 1
			msgs += "Invalid Score.<br>Should Be Between 0 And 100.\n"
			return render(request, "score.html", {"msgs": msgs, "e": el, "f": f})

		else:
			e = Element.objects.get(facility_id = f_id, measure_id = m_id)
			pre_score = e.score
			e.score = (e.score * e.sample + score) / (e.sample + 1)
			e.sample = e.sample + 1
			e.save()

			msgs += "Given Score: " + str(score) + "<br>"
			msgs += "Previous Score: " + str(pre_score) + "<br>"
			msgs += "New Score: " + str(e.score) + "<br>"
			msgs += "Total Scores (Sample): " + str(e.sample) + "<br>"

			return render(request, "score.html", {"msgs": msgs, "e": el, "f": f})
	else:
		if request.user.is_authenticated:
			return render(request, "score.html", {"e": el})
		else:
			return redirect("login")
