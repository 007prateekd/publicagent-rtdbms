from django.urls import path
from . import views

urlpatterns = [
	path("give-score", views.score, name = "score"),
] 