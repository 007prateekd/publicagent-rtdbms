from django.urls import path
from . import views

urlpatterns = [
	path("register", views.register, name = "register"),
	path("login", views.login, name = "login"),
	path("logout", views.logout, name = "logout"),
	path("verify/<auth_token>", views.verify, name = "verify"),
	path("error", views.error_page, name = "error"),
] 