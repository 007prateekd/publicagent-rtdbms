from root.models import Profile
import uuid
from django.conf import settings
from django.core.mail import send_mail
from django.contrib.auth import authenticate, login
from django.contrib.auth.decorators import login_required
from django.shortcuts import render, redirect
from django.contrib.auth.models import User, auth
from django.contrib import messages

def send_email(email, first_name, username, password, token):
	subject = 'Your Account Needs To Be Verified'
	message = f'Welcome {first_name} To PublicAgent.\n\n\
Username: {username}\n\
Password: {password}\n\n\
Click On The Following Link To Verify Your Account:\n\
http://127.0.0.1:8000/accounts/verify/{token}'
	email_from = settings.EMAIL_HOST_USER
	recipient_list = [email]
	send_mail(subject, message, email_from, recipient_list)

def login(request):
	if request.method == "POST":
		username = request.POST["username"]
		password = request.POST["password"]
		user = auth.authenticate(username = username, password = password)

		if user is not None:
			profile = Profile.objects.filter(user = user).first()
			if not profile.is_verified:
				messages.info(request, 'Profile Is Not Verified')
				messages.info(request, 'Check Your Mail')
				return redirect('login')

			auth.login(request, user)
			return redirect("/")
		else:
			messages.info(request, "Invalid Credentials")
			return redirect("login")
	else:
		if request.user.is_authenticated:
			return redirect("/")
		else:
			return render(request, "login.html")

def logout(request):
	auth.logout(request)
	return redirect("/")

def register(request):
	if request.method == "POST":
		first_name = request.POST["first_name"]
		last_name = request.POST["last_name"]
		username = request.POST["username"]
		email = request.POST["email"]
		password1 = request.POST["password1"]
		password2 = request.POST["password2"]

		flag = False
		if password1 != password2:
			flag = True
			messages.info(request, "Password Does Not Match")
		if User.objects.filter(username = username).exists():
			flag = True
			messages.info(request, "Username Taken")	
		if User.objects.filter(email = email).exists():
			flag = True
			messages.info(request, "Email Taken")

		if flag:
			return redirect("register")
		else:
			user = User.objects.create_user(
				username = username, password = password1, email = email, 
				first_name = first_name, last_name = last_name)
			user.set_password(password1)
			user.save()
			auth_token = str(uuid.uuid4())
			profile = Profile.objects.create(user = user, auth_token = auth_token)
			profile.save()
			send_email(email, first_name, username, password1, auth_token)
			messages.info(request, "Verification Mail Has Been Sent")
			return redirect("/accounts/login")

	else:
		if request.user.is_authenticated:
			return redirect("/")
		else:
			return render(request, "register.html")

def verify(request , auth_token):
    profile = Profile.objects.filter(auth_token = auth_token).first()
    if profile:
        if profile.is_verified:
            messages.info(request, 'Your Account Is Already Verified')
            return redirect('/accounts/login')
        profile.is_verified = True
        profile.save()
        messages.info(request, 'Your Account Has Been Verified')
        return redirect('/accounts/login')
    else:
        return redirect('/error')

def error_page(request):
    return render(request, 'error.html')

