from django.contrib import admin
from django.urls import path, include
from django.conf import settings
from django.conf.urls.static import static

urlpatterns = [
	path('', include('root.urls')),
    path('accounts/', include('accounts.urls')),
    path('graph/', include('graph.urls')),
    path('score/', include('score.urls')),
    path('facility/', include('facility.urls')),
    path('admin/', admin.site.urls),

]

urlpatterns = urlpatterns + static(settings.MEDIA_URL, document_root = settings.MEDIA_ROOT)